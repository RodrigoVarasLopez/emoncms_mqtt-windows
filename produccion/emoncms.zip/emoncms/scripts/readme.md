# feedwriter.php
'Low write' service will write feed data to engine in batch at certain times

# phpmqtt_input.php
MQTT input interface script, subscribes to MQTT topics. See [MQTT install nodes for documentation](https://github.com/emoncms/emoncms/blob/master/docs/RaspberryPi/MQTT.md) 

# input_queue_processor.php
To be used in association with que_input_controller.php see Modules > Input > [readme.md](https://github.com/emoncms/emoncms/blob/master/Modules/input/readme.md)
